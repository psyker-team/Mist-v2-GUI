import preparing_env


def start():
	print("Hello Mist!")


def main():
	preparing_env.prepare_environment()
	start()


if __name__ == "__main__":
	main()
