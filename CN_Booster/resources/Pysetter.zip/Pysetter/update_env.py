import preparing_env


def main():
	preparing_env.update_environment()


if __name__ == "__main__":
	main()
